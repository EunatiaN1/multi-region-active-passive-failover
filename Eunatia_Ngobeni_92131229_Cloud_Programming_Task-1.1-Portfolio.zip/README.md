# Multi-Region Active-Passive Failover

An interactive explainer for a proposed resilient AWS web architecture. Explore
how CloudFront, Route 53, regional origins, and health checks could work together
to route traffic from a primary region to a standby region.

> **Live demo:** [d2quyljtx3dqoe.cloudfront.net](https://d2quyljtx3dqoe.cloudfront.net/)

## What you'll find

- A responsive, interactive architecture diagram.
- Scenario controls that illustrate the documented request paths during normal
  operation and a simulated failover.
- An explanation of the AWS components and the role each would play.
- Terraform configuration for hosting this static explainer with a private S3
  bucket and CloudFront.

## Architecture scope

The scenario controls are an educational visualization. They do **not** trigger
or verify a real failover.

The live AWS deployment hosts only this static explainer. It does not include
the primary-region application, secondary-region maintenance origin,
CloudFront origin group, Route 53 failover records, health checks, or
CloudWatch/SNS alerting shown in the explainer. A separate Terraform
configuration is available in [`terraform/full-architecture/`](./terraform/full-architecture/).
That code defines CloudFront origin failover using an AWS-generated hostname;
it does not implement Route 53 DNS failover and has not been deployed or
runtime-tested. Its resources are billable, and the S3 website endpoint is
directly reachable over HTTP.
The full-architecture root includes plan-only Terraform tests with a mocked
AWS provider. These test selected configuration properties without AWS
credentials or creating resources; they do not replace deployment or runtime
failover testing. See the [evidence register](./Portfolio/03-Finalisation-Phase/validation-evidence.md)
for the verified and outstanding checks.

## Run locally

No build step or frontend dependencies are required. Open `index.html` directly
in a browser, or serve the repository with any static web server.

## Deploy the explainer to AWS

The Terraform in [`terraform/`](./terraform/) provisions the static website only:
a private S3 bucket, CloudFront distribution, and Origin Access Control.

Requirements for the static-site Terraform root:

- Terraform 1.5 or newer
- AWS CLI credentials with permission to create the resources above

Review the deployment steps, permissions, and cost considerations in the
[Terraform README](./terraform/README.md) before applying. AWS resources incur
charges while deployed.

The separate [full-architecture root](./terraform/full-architecture/) requires
Terraform 1.6 or newer and includes eight mocked, plan-only Terraform test
runs. They validate selected configuration properties without AWS credentials
or creating resources; they do not replace an AWS plan, deployment, or runtime
failover tests.

## Repository layout

| Path | Description |
| --- | --- |
| [`index.html`](./index.html) | Standalone interactive website |
| [`terraform/`](./terraform/) | Terraform for static-site hosting and the separate full architecture |
| [`Portfolio/`](./Portfolio/) | Written deliverables for the three assignment phases |

## License

No license has been specified. All rights are reserved unless the repository
owner adds a license.
